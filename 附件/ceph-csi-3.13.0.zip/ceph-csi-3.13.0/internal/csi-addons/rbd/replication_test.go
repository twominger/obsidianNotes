/*
Copyright 2021 The Ceph-CSI Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package rbd

import (
	"context"
	"errors"
	"reflect"
	"strconv"
	"strings"
	"testing"
	"time"

	corerbd "github.com/ceph/ceph-csi/internal/rbd"
	"github.com/ceph/ceph-csi/internal/rbd/types"
	"github.com/ceph/ceph-csi/internal/util"

	librbd "github.com/ceph/go-ceph/rbd"
	"github.com/ceph/go-ceph/rbd/admin"
	"github.com/csi-addons/spec/lib/go/replication"
	"github.com/stretchr/testify/require"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
	"google.golang.org/protobuf/types/known/durationpb"
	"google.golang.org/protobuf/types/known/timestamppb"
)

func TestValidateSchedulingInterval(t *testing.T) {
	t.Parallel()
	tests := []struct {
		name     string
		interval string
		wantErr  bool
	}{
		{
			"valid interval in minutes",
			"3m",
			false,
		},
		{
			"valid interval in hour",
			"22h",
			false,
		},
		{
			"valid interval in days",
			"13d",
			false,
		},
		{
			"invalid interval without number",
			"d",
			true,
		},
		{
			"invalid interval without (m|h|d) suffix",
			"12",
			true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			err := validateSchedulingInterval(tt.interval)
			if (err != nil) != tt.wantErr {
				t.Errorf("validateSchedulingInterval() error = %v, wantErr %v", err, tt.wantErr)

				return
			}
		})
	}
}

func TestValidateSchedulingDetails(t *testing.T) {
	t.Parallel()
	ctx := context.TODO()
	tests := []struct {
		name       string
		parameters map[string]string
		wantErr    bool
	}{
		{
			"valid parameters",
			map[string]string{
				imageMirroringKey:      string(imageMirrorModeSnapshot),
				schedulingIntervalKey:  "1h",
				schedulingStartTimeKey: "14:00:00-05:00",
			},
			false,
		},
		{
			"valid parameters when optional startTime is missing",
			map[string]string{
				imageMirroringKey:     string(imageMirrorModeSnapshot),
				schedulingIntervalKey: "1h",
			},
			false,
		},
		{
			"when mirroring mode is journal",
			map[string]string{
				imageMirroringKey:     string(imageMirrorModeJournal),
				schedulingIntervalKey: "1h",
			},
			false,
		},
		{
			"when startTime is specified without interval",
			map[string]string{
				imageMirroringKey:      string(imageMirrorModeSnapshot),
				schedulingStartTimeKey: "14:00:00-05:00",
			},
			true,
		},
		{
			"when no scheduling is specified",
			map[string]string{
				imageMirroringKey: string(imageMirrorModeSnapshot),
			},
			false,
		},
		{
			"when no parameters and scheduling details are specified",
			map[string]string{},
			false,
		},
		{
			"when no mirroring mode is specified",
			map[string]string{
				schedulingIntervalKey:  "1h",
				schedulingStartTimeKey: "14:00:00-05:00",
			},
			false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			err := validateSchedulingDetails(ctx, tt.parameters)
			if (err != nil) != tt.wantErr {
				t.Errorf("getSchedulingDetails() error = %v, wantErr %v", err, tt.wantErr)

				return
			}
		})
	}
}

func TestGetSchedulingDetails(t *testing.T) {
	t.Parallel()
	tests := []struct {
		name          string
		parameters    map[string]string
		wantInterval  admin.Interval
		wantStartTime admin.StartTime
	}{
		{
			"valid parameters",
			map[string]string{
				schedulingIntervalKey:  "1h",
				schedulingStartTimeKey: "14:00:00-05:00",
			},
			admin.Interval("1h"),
			admin.StartTime("14:00:00-05:00"),
		},
		{
			"valid parameters when optional startTime is missing",
			map[string]string{
				imageMirroringKey:     string(imageMirrorModeSnapshot),
				schedulingIntervalKey: "1h",
			},
			admin.Interval("1h"),
			admin.NoStartTime,
		},
		{
			"when startTime is specified without interval",
			map[string]string{
				imageMirroringKey:      string(imageMirrorModeSnapshot),
				schedulingStartTimeKey: "14:00:00-05:00",
			},
			admin.NoInterval,
			admin.StartTime("14:00:00-05:00"),
		},
		{
			"when no parameters and scheduling details are specified",
			map[string]string{},
			admin.NoInterval,
			admin.NoStartTime,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			interval, startTime := getSchedulingDetails(tt.parameters)
			if !reflect.DeepEqual(interval, tt.wantInterval) {
				t.Errorf("getSchedulingDetails() interval = %v, want %v", interval, tt.wantInterval)
			}
			if !reflect.DeepEqual(startTime, tt.wantStartTime) {
				t.Errorf("getSchedulingDetails() startTime = %v, want %v", startTime, tt.wantStartTime)
			}
		})
	}
}

func TestCheckVolumeResyncStatus(t *testing.T) {
	ctx := context.TODO()
	t.Parallel()
	tests := []struct {
		name    string
		args    corerbd.SiteMirrorImageStatus
		wantErr bool
	}{
		{
			name: "test when local_snapshot_timestamp is non zero",
			args: corerbd.SiteMirrorImageStatus{
				SiteMirrorImageStatus: librbd.SiteMirrorImageStatus{
					//nolint:lll // sample output cannot be split into multiple lines.
					Description: `replaying, {"bytes_per_second":0.0,"bytes_per_snapshot":81920.0,"last_snapshot_bytes":81920,"last_snapshot_sync_seconds":56743,"local_snapshot_timestamp":1684675261,"remote_snapshot_timestamp":1684675261,"replay_state":"idle"}`,
				},
			},
			wantErr: false,
		},
		{
			name: "test when local_snapshot_timestamp is zero",
			//nolint:lll // sample output cannot be split into multiple lines.
			args: corerbd.SiteMirrorImageStatus{
				SiteMirrorImageStatus: librbd.SiteMirrorImageStatus{
					Description: `replaying, {"bytes_per_second":0.0,"bytes_per_snapshot":81920.0,"last_snapshot_bytes":81920,"last_snapshot_sync_seconds":56743,"local_snapshot_timestamp":0,"remote_snapshot_timestamp":1684675261,"replay_state":"idle"}`,
				},
			},
			wantErr: true,
		},
		{
			name: "test when local_snapshot_timestamp is not present",
			//nolint:lll // sample output cannot be split into multiple lines.
			args: corerbd.SiteMirrorImageStatus{
				SiteMirrorImageStatus: librbd.SiteMirrorImageStatus{
					Description: `replaying, {"bytes_per_second":0.0,"bytes_per_snapshot":81920.0,"last_snapshot_bytes":81920,"last_snapshot_sync_seconds":56743,"remote_snapshot_timestamp":1684675261,"replay_state":"idle"}`,
				},
			},
			wantErr: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			if err := checkVolumeResyncStatus(ctx, tt.args); (err != nil) != tt.wantErr {
				t.Errorf("checkVolumeResyncStatus() error = %v, expect error = %v", err, tt.wantErr)
			}
		})
	}
}

func TestCheckRemoteSiteStatus(t *testing.T) {
	t.Parallel()
	tests := []struct {
		name      string
		args      corerbd.GlobalMirrorStatus
		wantReady bool
	}{
		{
			name: "Test a single peer in sync",
			args: corerbd.GlobalMirrorStatus{
				GlobalMirrorImageStatus: librbd.GlobalMirrorImageStatus{
					SiteStatuses: []librbd.SiteMirrorImageStatus{
						{
							MirrorUUID: "remote",
							State:      librbd.MirrorImageStatusStateUnknown,
							Up:         true,
						},
					},
				},
			},
			wantReady: true,
		},
		{
			name: "Test a single peer in sync, including a local instance",
			args: corerbd.GlobalMirrorStatus{
				GlobalMirrorImageStatus: librbd.GlobalMirrorImageStatus{
					SiteStatuses: []librbd.SiteMirrorImageStatus{
						{
							MirrorUUID: "remote",
							State:      librbd.MirrorImageStatusStateUnknown,
							Up:         true,
						},
						{
							MirrorUUID: "",
							State:      librbd.MirrorImageStatusStateUnknown,
							Up:         true,
						},
					},
				},
			},
			wantReady: true,
		},
		{
			name: "Test a multiple peers in sync",
			args: corerbd.GlobalMirrorStatus{
				GlobalMirrorImageStatus: librbd.GlobalMirrorImageStatus{
					SiteStatuses: []librbd.SiteMirrorImageStatus{
						{
							MirrorUUID: "remote1",
							State:      librbd.MirrorImageStatusStateUnknown,
							Up:         true,
						},
						{
							MirrorUUID: "remote2",
							State:      librbd.MirrorImageStatusStateUnknown,
							Up:         true,
						},
					},
				},
			},
			wantReady: true,
		},
		{
			name: "Test no remote peers",
			args: corerbd.GlobalMirrorStatus{
				GlobalMirrorImageStatus: librbd.GlobalMirrorImageStatus{
					SiteStatuses: []librbd.SiteMirrorImageStatus{},
				},
			},
			wantReady: false,
		},
		{
			name: "Test single peer not in sync",
			args: corerbd.GlobalMirrorStatus{
				GlobalMirrorImageStatus: librbd.GlobalMirrorImageStatus{
					SiteStatuses: []librbd.SiteMirrorImageStatus{
						{
							MirrorUUID: "remote",
							State:      librbd.MirrorImageStatusStateReplaying,
							Up:         true,
						},
					},
				},
			},
			wantReady: false,
		},
		{
			name: "Test single peer not up",
			args: corerbd.GlobalMirrorStatus{
				GlobalMirrorImageStatus: librbd.GlobalMirrorImageStatus{
					SiteStatuses: []librbd.SiteMirrorImageStatus{
						{
							MirrorUUID: "remote",
							State:      librbd.MirrorImageStatusStateUnknown,
							Up:         false,
						},
					},
				},
			},
			wantReady: false,
		},
		{
			name: "Test multiple peers, when first peer is not in sync",
			args: corerbd.GlobalMirrorStatus{
				GlobalMirrorImageStatus: librbd.GlobalMirrorImageStatus{
					SiteStatuses: []librbd.SiteMirrorImageStatus{
						{
							MirrorUUID: "remote1",
							State:      librbd.MirrorImageStatusStateStoppingReplay,
							Up:         true,
						},
						{
							MirrorUUID: "remote2",
							State:      librbd.MirrorImageStatusStateUnknown,
							Up:         true,
						},
					},
				},
			},
			wantReady: false,
		},
		{
			name: "Test multiple peers, when second peer is not up",
			args: corerbd.GlobalMirrorStatus{
				GlobalMirrorImageStatus: librbd.GlobalMirrorImageStatus{
					SiteStatuses: []librbd.SiteMirrorImageStatus{
						{
							MirrorUUID: "remote1",
							State:      librbd.MirrorImageStatusStateUnknown,
							Up:         true,
						},
						{
							MirrorUUID: "remote2",
							State:      librbd.MirrorImageStatusStateUnknown,
							Up:         false,
						},
					},
				},
			},
			wantReady: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			if ready := checkRemoteSiteStatus(context.TODO(), tt.args.GetAllSitesStatus()); ready != tt.wantReady {
				t.Errorf("checkRemoteSiteStatus() ready = %v, expect ready = %v", ready, tt.wantReady)
			}
		})
	}
}

func TestValidateLastSyncInfo(t *testing.T) {
	t.Parallel()
	ctx := context.TODO()
	duration, err := time.ParseDuration(strconv.Itoa(int(56743)) + "s")
	if err != nil {
		t.Errorf("failed to parse duration)")
	}

	tests := []struct {
		name        string
		description string
		info        *replication.GetVolumeReplicationInfoResponse
		expectedErr string
	}{
		{
			name: "valid description",
			//nolint:lll // sample output cannot be split into multiple lines.
			description: `replaying, {"bytes_per_second":0.0,"bytes_per_snapshot":81920.0,"last_snapshot_bytes":81920,"last_snapshot_sync_seconds":56743,"local_snapshot_timestamp":1684675261,"remote_snapshot_timestamp":1684675261,"replay_state":"idle"}`,
			info: &replication.GetVolumeReplicationInfoResponse{
				LastSyncTime:     timestamppb.New(time.Unix(1684675261, 0)),
				LastSyncDuration: durationpb.New(duration),
				LastSyncBytes:    81920,
			},
			expectedErr: "",
		},
		{
			name:        "empty description",
			description: "",
			info: &replication.GetVolumeReplicationInfoResponse{
				LastSyncTime:     nil,
				LastSyncDuration: nil,
				LastSyncBytes:    0,
			},
			expectedErr: corerbd.ErrLastSyncTimeNotFound.Error(),
		},
		{
			name: "description without last_snapshot_bytes",
			//nolint:lll // sample output cannot be split into multiple lines.
			description: `replaying, {"bytes_per_second":0.0,"last_snapshot_sync_seconds":56743,"local_snapshot_timestamp":1684675261,"remote_snapshot_timestamp":1684675261,"replay_state":"idle"}`,
			info: &replication.GetVolumeReplicationInfoResponse{
				LastSyncDuration: durationpb.New(duration),
				LastSyncTime:     timestamppb.New(time.Unix(1684675261, 0)),
				LastSyncBytes:    0,
			},
			expectedErr: "",
		},
		{
			name: "description without local_snapshot_time",
			//nolint:lll // sample output cannot be split into multiple lines.
			description: `replaying, {"bytes_per_second":0.0,"bytes_per_snapshot":81920.0,"last_snapshot_bytes":81920,"last_snapshot_sync_seconds":56743,"remote_snapshot_timestamp":1684675261,"replay_state":"idle"}`,
			info: &replication.GetVolumeReplicationInfoResponse{
				LastSyncDuration: nil,
				LastSyncTime:     nil,
				LastSyncBytes:    0,
			},
			expectedErr: corerbd.ErrLastSyncTimeNotFound.Error(),
		},
		{
			name: "description without last_snapshot_sync_seconds",
			//nolint:lll // sample output cannot be split into multiple lines.
			description: `replaying, {"bytes_per_second":0.0,"bytes_per_snapshot":81920.0,"last_snapshot_bytes":81920,"local_snapshot_timestamp":1684675261,"remote_snapshot_timestamp":1684675261,"replay_state":"idle"}`,
			info: &replication.GetVolumeReplicationInfoResponse{
				LastSyncDuration: nil,
				LastSyncTime:     timestamppb.New(time.Unix(1684675261, 0)),
				LastSyncBytes:    81920,
			},
			expectedErr: "",
		},
		{
			name: "description with last_snapshot_sync_seconds = 0",
			//nolint:lll // sample output cannot be split into multiple lines.
			description: `replaying, {"bytes_per_second":0.0,"bytes_per_snapshot":81920.0,"last_snapshot_sync_seconds":0,
			"last_snapshot_bytes":81920,"local_snapshot_timestamp":1684675261,"remote_snapshot_timestamp":1684675261,"replay_state":"idle"}`,
			info: &replication.GetVolumeReplicationInfoResponse{
				LastSyncDuration: durationpb.New(time.Duration(0)),
				LastSyncTime:     timestamppb.New(time.Unix(1684675261, 0)),
				LastSyncBytes:    81920,
			},
			expectedErr: "",
		},
		{
			name: "description with invalid JSON",
			//nolint:lll // sample output cannot be split into multiple lines.
			description: `replaying,{"bytes_per_second":0.0,"last_snapshot_bytes":81920","bytes_per_snapshot":149504.0","remote_snapshot_timestamp":1662655501`,
			info: &replication.GetVolumeReplicationInfoResponse{
				LastSyncDuration: nil,
				LastSyncTime:     nil,
				LastSyncBytes:    0,
			},
			expectedErr: "failed to unmarshal",
		},
		{
			name:        "description with no JSON",
			description: `replaying`,
			info: &replication.GetVolumeReplicationInfoResponse{
				LastSyncDuration: nil,
				LastSyncTime:     nil,
				LastSyncBytes:    0,
			},
			expectedErr: corerbd.ErrLastSyncTimeNotFound.Error(),
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			teststruct, err := getLastSyncInfo(ctx, tt.description)
			if err != nil && !strings.Contains(err.Error(), tt.expectedErr) {
				// returned error
				t.Errorf("getLastSyncInfo() returned error, expected: %v, got: %v",
					tt.expectedErr, err)
			}
			if teststruct != nil {
				if teststruct.GetLastSyncTime().GetSeconds() != tt.info.GetLastSyncTime().GetSeconds() {
					t.Errorf("name: %v, getLastSyncInfo() %v, expected %v",
						tt.name,
						teststruct.GetLastSyncTime(),
						tt.info.GetLastSyncTime())
				}
				if tt.info.GetLastSyncDuration() == nil && teststruct.GetLastSyncDuration() != nil {
					t.Errorf("name: %v, getLastSyncInfo() %v, expected %v",
						tt.name,
						teststruct.GetLastSyncDuration(),
						tt.info.GetLastSyncDuration())
				}
				if teststruct.GetLastSyncDuration().GetSeconds() != tt.info.GetLastSyncDuration().GetSeconds() {
					t.Errorf("name: %v, getLastSyncInfo() %v, expected %v",
						tt.name,
						teststruct.GetLastSyncDuration(),
						tt.info.GetLastSyncDuration())
				}
				if teststruct.GetLastSyncBytes() != tt.info.GetLastSyncBytes() {
					t.Errorf("name: %v, getLastSyncInfo() %v, expected %v",
						tt.name,
						teststruct.GetLastSyncBytes(),
						tt.info.GetLastSyncBytes())
				}
			}
		})
	}
}

func TestGetGRPCError(t *testing.T) {
	t.Parallel()
	tests := []struct {
		name        string
		err         error
		expectedErr error
	}{
		{
			name:        "InvalidArgument",
			err:         corerbd.ErrInvalidArgument,
			expectedErr: status.Error(codes.InvalidArgument, corerbd.ErrInvalidArgument.Error()),
		},
		{
			name:        "Aborted",
			err:         corerbd.ErrAborted,
			expectedErr: status.Error(codes.Aborted, corerbd.ErrAborted.Error()),
		},
		{
			name:        "FailedPrecondition",
			err:         corerbd.ErrFailedPrecondition,
			expectedErr: status.Error(codes.FailedPrecondition, corerbd.ErrFailedPrecondition.Error()),
		},
		{
			name:        "Unavailable",
			err:         corerbd.ErrUnavailable,
			expectedErr: status.Error(codes.Unavailable, corerbd.ErrUnavailable.Error()),
		},
		{
			name:        "InvalidError",
			err:         errors.New("some error"),
			expectedErr: status.Error(codes.Internal, "some error"),
		},
		{
			name:        "NilError",
			err:         nil,
			expectedErr: status.Error(codes.OK, "ok string"),
		},
		{
			name:        "ErrImageNotFound",
			err:         corerbd.ErrImageNotFound,
			expectedErr: status.Error(codes.NotFound, corerbd.ErrImageNotFound.Error()),
		},
		{
			name:        "ErrPoolNotFound",
			err:         util.ErrPoolNotFound,
			expectedErr: status.Error(codes.NotFound, util.ErrPoolNotFound.Error()),
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			result := getGRPCError(tt.err)
			require.Equal(t, tt.expectedErr, result)
		})
	}
}

func Test_timestampFromString(t *testing.T) {
	tm := time.Now()
	t.Parallel()
	tests := []struct {
		name      string
		timestamp string
		want      time.Time
		wantErr   bool
	}{
		{
			name:      "valid timestamp",
			timestamp: timestampToString(&tm),
			want:      tm,
			wantErr:   false,
		},
		{
			name:      "invalid timestamp",
			timestamp: "invalid",
			want:      time.Time{},
			wantErr:   true,
		},
		{
			name:      "empty timestamp",
			timestamp: "",
			want:      time.Time{},
			wantErr:   true,
		},
		{
			name:      "invalid format",
			timestamp: "seconds:%d nanos:%d",
			want:      time.Time{},
			wantErr:   true,
		},
		{
			name:      "missing nanos",
			timestamp: "seconds:10",
			want:      time.Time{},
			wantErr:   true,
		},
		{
			name:      "missing seconds",
			timestamp: "nanos:0",
			want:      time.Time{},
			wantErr:   true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			got, err := timestampFromString(tt.timestamp)
			if (err != nil) != tt.wantErr {
				t.Errorf("timestampFromString() error = %v, wantErr %v", err, tt.wantErr)
			}
			if !tt.want.Equal(got) {
				t.Errorf("timestampFromString() = %q, want %q", got, tt.want)
			}
		})
	}
}

func Test_getFlattenMode(t *testing.T) {
	t.Parallel()
	type args struct {
		ctx        context.Context
		parameters map[string]string
	}
	tests := []struct {
		name    string
		args    args
		want    types.FlattenMode
		wantErr bool
	}{
		{
			name: "flattenMode option not set",
			args: args{
				ctx:        context.TODO(),
				parameters: map[string]string{},
			},
			want: types.FlattenModeNever,
		},
		{
			name: "flattenMode option set to never",
			args: args{
				ctx: context.TODO(),
				parameters: map[string]string{
					flattenModeKey: string(types.FlattenModeNever),
				},
			},
			want: types.FlattenModeNever,
		},
		{
			name: "flattenMode option set to force",
			args: args{
				ctx: context.TODO(),
				parameters: map[string]string{
					flattenModeKey: string(types.FlattenModeForce),
				},
			},
			want: types.FlattenModeForce,
		},

		{
			name: "flattenMode option set to invalid value",
			args: args{
				ctx: context.TODO(),
				parameters: map[string]string{
					flattenModeKey: "invalid123",
				},
			},
			wantErr: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			got, err := getFlattenMode(tt.args.ctx, tt.args.parameters)
			if (err != nil) != tt.wantErr {
				t.Errorf("getFlattenMode() error = %v, wantErr %v", err, tt.wantErr)
			}
			if !tt.wantErr && !reflect.DeepEqual(got, tt.want) {
				t.Errorf("getFlattenMode() = %v, want %v", got, tt.want)
			}
		})
	}
}
